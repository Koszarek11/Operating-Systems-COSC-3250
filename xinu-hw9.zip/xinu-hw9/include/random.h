#ifndef _RANDOM_H_
#define _RANDOM_H_

void seed_random(uint x);
int random(uint max);

#endif                          /* _RANDOM_H_ */
