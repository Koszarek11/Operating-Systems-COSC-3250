#define VERSION "(Embedded Xinu) (arm-rpi3) #462 (vinfusino@morbius) Thu May 5 11:30:24 CDT 2022"
